package com.org.tcs.bean;

public interface Employee {
	
	void doWork();

}
